﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsCapitalConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a max number");
            long n = 0;
            try
            {
                n = Int64.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Enter a number");
                n = Int64.Parse(Console.ReadLine());
            }

            CountNumbers(n);
            //CountNumbersWithArray(n);


            Console.WriteLine("Enter to exit");
            Console.ReadLine();
        }

        #region Using array

        public static void CountNumbers(long maxLimit)
        {
            Int64[] longNumbers = new Int64[maxLimit];
            for (Int64 i = 0; i < maxLimit; i++)
            {
                longNumbers[i] = i;
            }

            for (var i = 0; i < 10; i++)
            {
                PrintNumbers(i, GetCount(longNumbers, Char.Parse(i.ToString())));
            }
        }
        private static int GetCount(Int64[] longNumbers, char digit)
        {
            var count = longNumbers.Select(number => number.ToString())
                                        .SelectMany(numberString => numberString.ToCharArray())
                                        .Count(c => c == digit);
            return count;
        }

        #endregion Using array

        #region Using zagged array to overcome Overflow exception

        private static void CountNumbersWithArray(long maxLimit)
        {
            int[,] counts = new int[10, 2];

            for (Int64 i = 1; i <= maxLimit; i++)
            {
                for (var j = 0; j < 10; j++)
                {
                    var count = GetCount(i, Char.Parse(j.ToString()));
                    counts[j, 0] = j;
                    counts[j, 1] = counts[j, 1] + count;
                }
            }

            for (var i = 0; i < 10; i++)
            {
                PrintNumbers(counts[i, 0], counts[i, 1]);
            }
        }
        private static int GetCount(Int64 longNumber, char digit)
        {
            var count = longNumber.ToString().ToCharArray().Count(c => c == digit);
            return count;
        }

        #endregion Using zagged array to overcome Overflow exception


        private static void PrintNumbers(Int64 i, int count)
        {
            Console.WriteLine(String.Format("{0} count: {1}", i, count));
        }

    }
}
