﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace BookATableMin.Classes
{
    public abstract class GitSearch
    {
        public static readonly HttpClient Client = new HttpClient();
        private string _searchUrlTemplate;
        public string SearchUrlTemplate { get { return _searchUrlTemplate; } }

        public GitSearch()
        {
            if (Client.BaseAddress != null)
                Client.BaseAddress = new Uri("http://localhost:55268/");            
        }

        public GitSearch(string searchUrlTemplate) : this()
        {
            _searchUrlTemplate = searchUrlTemplate;
        }

        public async Task<T> GetGitDataAsync<T>(string path)
        {
            T repository = default(T);
            HttpResponseMessage response = Client.GetAsync(path).Result;
            if (response.IsSuccessStatusCode)
            {
                repository = await response.Content.ReadAsAsync<T>();
            }
            return repository;
        }
    }

}