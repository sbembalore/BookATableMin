﻿using System;
using System.Collections.Generic;
using System.Linq;
using BookATableMin.Models;

namespace BookATableMin.Classes
{
    sealed class GitRepositorySearch : GitSearch
    {
        public GitRepositorySearch(string searchUrlTemplate)
            : base(searchUrlTemplate)
        {
            Client.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
        }

        public IEnumerable<RepositoryModel> GetGitData(string searchText)
        {
           var path = String.Format(SearchUrlTemplate, searchText);
            var response = GetGitDataAsync<RepositoryListModel>(path).Result.Items.OrderByDescending(r => r.Score).Take(5);
            return response;
        }
    }
}