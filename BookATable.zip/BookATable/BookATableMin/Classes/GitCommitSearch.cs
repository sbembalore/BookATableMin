﻿using System;
using System.Linq;
using System.Collections.Generic;
using BookATableMin.Models;

namespace BookATableMin.Classes
{
    sealed class GitCommitSearch : GitSearch
    {
        public GitCommitSearch(string searchUrlTemplate)
            : base(searchUrlTemplate)
        {
            Client.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
            Client.DefaultRequestHeaders.Add("Accept", "application/vnd.github.cloak-preview");
        }

        public void AddCommits(RepositoryModel repository)
        {
            var path = String.Format(SearchUrlTemplate, repository.Full_Name);
            var response = GetGitDataAsync<List<CommitModel>>(path).Result;
            if (response != null)
            {
                var latestCommits = response.OrderByDescending(o=>o.Commit.Committer.Date).Take(5);
                repository.Commits.AddRange(latestCommits);
            }
        }
    }
}