﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookATableMin.Models
{
    public class CommitModel
    {
        public string Sha{get;set;}
        public CommitDetailModel Commit{get;set;}
        public CommitRepositoryModel Repository { get; set; }
    }

    public class CommitDetailModel
    {
        public CommitterModel Committer{get;set;}
        public string Message{get;set;}
    }

    public class CommitterModel
    {
        public DateTime Date { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

    public class CommitRepositoryModel
    {
        public int Id { get; set; }
    }
}