﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookATableMin.Models
{
    public class RepositoryListModel
    {
        public int Total_Count { get; set; }
        public bool Incomplete_Results { get; set; }
        public IEnumerable<RepositoryModel> Items {get;set;} 
        
    }
    public class RepositoryModel
    {
        public RepositoryModel()
        {
            Commits = new List<CommitModel>();
        }

        public int Id { get; set; }
        public OwnerModel Owner { get; set; }
        public string Full_Name { get; set; }
        public string Html_Url { get; set; }
        public DateTime Created_At { get; set; }
        public DateTime Pushed_At { get; set; }
        public double Score { get; set; }
        public List<CommitModel> Commits { get; private set; }
    }

    public class OwnerModel
    {
        public string Login { get; set; }
    }
}