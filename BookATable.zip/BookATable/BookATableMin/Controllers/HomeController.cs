﻿using System.Web.Mvc;
using BookATableMin.Classes;

namespace BookATable.Controllers
{
    public class HomeController : Controller
    {
        private const string commitsSearchPath = "https://api.github.com/repos/{0}/commits";
        private const string repositorySearchPath = "https://api.github.com/search/repositories?q={0}&sort=stars&order=desc";
        
        public ActionResult Index()
        {
            //ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        [HttpPost]
        public ActionResult Index(string txtRepository)
        {
            var repositorySearch = new GitRepositorySearch(repositorySearchPath);
            var repositories = repositorySearch.GetGitData(txtRepository);

            var commits = new GitCommitSearch(commitsSearchPath); 
            foreach (var item in repositories)
            {
                commits.AddCommits(item);
            }

            return View(repositories);
        }
    }
}
